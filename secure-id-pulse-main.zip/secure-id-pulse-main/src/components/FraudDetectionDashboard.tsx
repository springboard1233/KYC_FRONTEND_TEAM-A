import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  TrendingUp, 
  Users, 
  FileText, 
  Eye,
  Brain
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface FraudDetectionProps {
  document: any;
}

const FraudDetectionDashboard = ({ document }: FraudDetectionProps) => {
  const [fraudScore, setFraudScore] = useState(0);
  const [riskLevel, setRiskLevel] = useState("LOW");
  const [detectionResults, setDetectionResults] = useState<any>(null);

  useEffect(() => {
    if (document && document.verification_results) {
      calculateFraudScore();
    }
  }, [document]);

  const calculateFraudScore = () => {
    // AI-powered fraud scoring algorithm
    const results = document.verification_results;
    let totalScore = 0;
    let penalties = 0;

    // Document authenticity check (+30 points)
    if (results.document_authenticity?.score >= 95) totalScore += 30;
    else if (results.document_authenticity?.score >= 80) totalScore += 20;
    else penalties += 15;

    // Template matching (+25 points)  
    if (results.template_matching?.score >= 95) totalScore += 25;
    else if (results.template_matching?.score >= 80) totalScore += 15;
    else penalties += 10;

    // Security features (+20 points)
    if (results.security_features?.score >= 95) totalScore += 20;
    else if (results.security_features?.score >= 80) totalScore += 15;
    else penalties += 10;

    // AI fraud detection (+15 points)
    if (results.fraud_detection?.score >= 95) totalScore += 15;
    else penalties += 20;

    // Data validation (+10 points)
    if (results.data_validation?.score >= 90) totalScore += 10;
    else penalties += 5;

    const finalScore = Math.max(0, totalScore - penalties);
    setFraudScore(finalScore);

    // Determine risk level
    if (finalScore >= 80) setRiskLevel("LOW");
    else if (finalScore >= 60) setRiskLevel("MEDIUM");
    else if (finalScore >= 40) setRiskLevel("HIGH");
    else setRiskLevel("CRITICAL");

    // Mock additional fraud detection results
    setDetectionResults({
      name_matching: { score: 95.8, status: "passed", confidence: "high" },
      duplicate_check: { score: 100, status: "passed", duplicates_found: 0 },
      tampering_detection: { score: 97.2, status: "passed", anomalies: 0 },
      biometric_verification: { score: 94.5, status: "passed", match_confidence: 94.5 },
      document_age: { score: 88.3, status: "passed", estimated_age: "2+ years" }
    });
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case "LOW": return "text-success";
      case "MEDIUM": return "text-warning";
      case "HIGH": return "text-orange-500";
      case "CRITICAL": return "text-destructive";
      default: return "text-muted-foreground";
    }
  };

  const getRiskBgColor = (level: string) => {
    switch (level) {
      case "LOW": return "bg-success/10";
      case "MEDIUM": return "bg-warning/10";
      case "HIGH": return "bg-orange-500/10";
      case "CRITICAL": return "bg-destructive/10";
      default: return "bg-muted";
    }
  };

  // Chart data
  const riskCategoriesData = [
    { name: 'Document Auth', score: document?.verification_results?.document_authenticity?.score || 0 },
    { name: 'Template Match', score: document?.verification_results?.template_matching?.score || 0 },
    { name: 'Security Features', score: document?.verification_results?.security_features?.score || 0 },
    { name: 'Fraud Detection', score: document?.verification_results?.fraud_detection?.score || 0 },
    { name: 'Data Validation', score: document?.verification_results?.data_validation?.score || 0 }
  ];

  const verificationStatusData = [
    { name: 'Verified', value: 85, fill: '#10B981' },
    { name: 'Flagged', value: 12, fill: '#F59E0B' },
    { name: 'Rejected', value: 3, fill: '#EF4444' }
  ];

  return (
    <div className="space-y-6">
      {/* Fraud Risk Score Header */}
      <Card className="shadow-elegant border-border/50">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Brain className="h-6 w-6 text-primary" />
              <CardTitle className="text-xl">AI Fraud Detection Analysis</CardTitle>
            </div>
            <Badge variant="outline" className={getRiskColor(riskLevel)}>
              {riskLevel} RISK
            </Badge>
          </div>
          <CardDescription>
            Comprehensive fraud analysis using advanced AI algorithms
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Overall Fraud Score */}
            <div className="text-center">
              <div className={`mx-auto w-24 h-24 rounded-full ${getRiskBgColor(riskLevel)} flex items-center justify-center mb-3`}>
                <span className={`text-2xl font-bold ${getRiskColor(riskLevel)}`}>
                  {fraudScore}%
                </span>
              </div>
              <h3 className="font-semibold text-foreground mb-1">Fraud Score</h3>
              <p className="text-sm text-muted-foreground">Overall Safety Rating</p>
            </div>

            {/* Risk Level Indicator */}
            <div className="space-y-3">
              <h3 className="font-semibold text-foreground">Risk Assessment</h3>
              <Progress value={fraudScore} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>High Risk</span>
                <span>Low Risk</span>
              </div>
              <div className={`text-center p-2 rounded-lg ${getRiskBgColor(riskLevel)}`}>
                <span className={`font-medium ${getRiskColor(riskLevel)}`}>
                  {riskLevel} RISK DETECTED
                </span>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Authenticity</span>
                <span className="font-medium">{document?.verification_results?.document_authenticity?.score || 0}%</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Template Match</span>
                <span className="font-medium">{document?.verification_results?.template_matching?.score || 0}%</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Security Check</span>
                <span className="font-medium">{document?.verification_results?.security_features?.score || 0}%</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Data Integrity</span>
                <span className="font-medium">{document?.verification_results?.data_validation?.score || 0}%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Analysis Results */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* AI Detection Results */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-primary" />
              <span>AI Detection Results</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {detectionResults && (
              <div className="space-y-4">
                {Object.entries(detectionResults).map(([key, result]: [string, any]) => (
                  <div key={key} className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div className="flex items-center space-x-3">
                      {result.status === 'passed' ? (
                        <CheckCircle className="h-4 w-4 text-success" />
                      ) : (
                        <XCircle className="h-4 w-4 text-destructive" />
                      )}
                      <span className="font-medium capitalize">
                        {key.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-muted-foreground">
                        {result.score}%
                      </span>
                      <Badge variant={result.status === 'passed' ? 'default' : 'destructive'} className="text-xs">
                        {result.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Risk Categories Chart */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <span>Risk Categories Analysis</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={riskCategoriesData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" fontSize={12} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="score" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Verification Status Distribution */}
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <FileText className="h-5 w-5 text-primary" />
            <span>Document Verification Distribution</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={verificationStatusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  dataKey="value"
                >
                  {verificationStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-3">
              {verificationStatusData.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: item.fill }}
                    ></div>
                    <span className="text-sm font-medium">{item.name}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">{item.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Recommendations */}
      {fraudScore < 70 && (
        <Alert className="border-destructive/20 bg-destructive/5">
          <AlertTriangle className="h-4 w-4 text-destructive" />
          <AlertDescription className="text-destructive">
            <strong>High Risk Detected:</strong> This document has failed multiple security checks. 
            Manual review is required before approval. Consider requesting additional documentation.
          </AlertDescription>
        </Alert>
      )}

      {fraudScore >= 70 && fraudScore < 85 && (
        <Alert className="border-warning/20 bg-warning/5">
          <AlertTriangle className="h-4 w-4 text-warning" />
          <AlertDescription className="text-warning">
            <strong>Medium Risk:</strong> Document passed basic checks but requires additional verification. 
            Consider implementing secondary authentication measures.
          </AlertDescription>
        </Alert>
      )}

      {fraudScore >= 85 && (
        <Alert className="border-success/20 bg-success/5">
          <CheckCircle className="h-4 w-4 text-success" />
          <AlertDescription className="text-success">
            <strong>Low Risk:</strong> Document has passed all security checks with high confidence. 
            Safe to proceed with verification approval.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
};

export default FraudDetectionDashboard;