import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Shield, 
  Users, 
  FileText, 
  Eye, 
  CheckCircle, 
  XCircle, 
  Clock,
  Search,
  Filter,
  Download,
  AlertTriangle
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface DocumentReview {
  id: string;
  user_name: string;
  document_type: string;
  verification_status: string;
  confidence_score: number;
  fraud_score: number;
  created_at: string;
  extracted_data: any;
  verification_results: any;
}

const AdminPanel = () => {
  const { user } = useAuth();
  const [documents, setDocuments] = useState<DocumentReview[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDoc, setSelectedDoc] = useState<DocumentReview | null>(null);
  const [reviewAction, setReviewAction] = useState<'approve' | 'reject' | ''>('');
  const [reviewComments, setReviewComments] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchPendingDocuments();
  }, []);

  const fetchPendingDocuments = async () => {
    try {
      // Mock data for admin panel - in real implementation, this would fetch from database
      const mockDocuments: DocumentReview[] = [
        {
          id: '1',
          user_name: 'Rahul Kumar Singh',
          document_type: 'aadhaar',
          verification_status: 'pending_review',
          confidence_score: 67.5,
          fraud_score: 45,
          created_at: '2024-01-15T10:30:00Z',
          extracted_data: {
            full_name: 'Rahul Kumar Singh',
            aadhaar_number: 'XXXX XXXX 1234'
          },
          verification_results: {
            document_authenticity: { score: 75.2 },
            template_matching: { score: 68.9 },
            fraud_detection: { score: 45.3 }
          }
        },
        {
          id: '2', 
          user_name: 'Priya Patel',
          document_type: 'pan',
          verification_status: 'flagged',
          confidence_score: 34.2,
          fraud_score: 25,
          created_at: '2024-01-15T09:15:00Z',
          extracted_data: {
            full_name: 'Priya Patel',
            pan_number: 'ABCDE1234F'
          },
          verification_results: {
            document_authenticity: { score: 45.1 },
            template_matching: { score: 32.8 },
            fraud_detection: { score: 25.7 }
          }
        },
        {
          id: '3',
          user_name: 'Amit Kumar Sharma',
          document_type: 'driving_license',
          verification_status: 'pending_review',
          confidence_score: 89.3,
          fraud_score: 92,
          created_at: '2024-01-15T08:45:00Z',
          extracted_data: {
            full_name: 'Amit Kumar Sharma',
            license_number: 'DL1420110012345'
          },
          verification_results: {
            document_authenticity: { score: 94.5 },
            template_matching: { score: 91.2 },
            fraud_detection: { score: 92.8 }
          }
        }
      ];

      setDocuments(mockDocuments);
    } catch (error: any) {
      toast({
        title: "Error loading documents",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleReviewSubmit = async () => {
    if (!selectedDoc || !reviewAction) return;

    try {
      // Mock API call - in real implementation, update document status
      const newStatus = reviewAction === 'approve' ? 'verified' : 'rejected';
      
      // Update local state
      setDocuments(prev => 
        prev.map(doc => 
          doc.id === selectedDoc.id 
            ? { ...doc, verification_status: newStatus }
            : doc
        )
      );

      toast({
        title: `Document ${reviewAction}d`,
        description: `Document has been successfully ${reviewAction}d.`,
      });

      setSelectedDoc(null);
      setReviewAction('');
      setReviewComments('');
    } catch (error: any) {
      toast({
        title: "Error updating document",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified': return 'success';
      case 'rejected': return 'destructive';
      case 'flagged': return 'warning';
      case 'pending_review': return 'secondary';
      default: return 'outline';
    }
  };

  const getRiskLevel = (fraudScore: number) => {
    if (fraudScore >= 80) return { label: 'LOW', color: 'text-success' };
    if (fraudScore >= 60) return { label: 'MEDIUM', color: 'text-warning' };
    if (fraudScore >= 40) return { label: 'HIGH', color: 'text-orange-500' };
    return { label: 'CRITICAL', color: 'text-destructive' };
  };

  const getDocumentTypeDisplay = (type: string) => {
    switch (type) {
      case 'aadhaar': return 'Aadhaar Card';
      case 'pan': return 'PAN Card';
      case 'driving_license': return 'Driving License';
      default: return type;
    }
  };

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.user_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doc.document_type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || doc.verification_status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  if (loading) {
    return (
      <div className="min-h-screen pt-20 pb-16 gradient-subtle flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading admin panel...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 pb-16 gradient-subtle">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center space-x-3 mb-2">
              <div className="p-2 gradient-primary rounded-lg">
                <Shield className="h-6 w-6 text-primary-foreground" />
              </div>
              <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
            </div>
            <p className="text-muted-foreground">
              Review and manage document verifications, approve or reject KYC submissions
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">Pending Review</p>
                    <p className="text-2xl font-bold text-foreground">
                      {documents.filter(d => d.verification_status === 'pending_review').length}
                    </p>
                  </div>
                  <Clock className="h-8 w-8 text-warning" />
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">Flagged</p>
                    <p className="text-2xl font-bold text-foreground">
                      {documents.filter(d => d.verification_status === 'flagged').length}
                    </p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-destructive" />
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">Verified</p>
                    <p className="text-2xl font-bold text-foreground">
                      {documents.filter(d => d.verification_status === 'verified').length}
                    </p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-success" />
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">Rejected</p>
                    <p className="text-2xl font-bold text-foreground">
                      {documents.filter(d => d.verification_status === 'rejected').length}
                    </p>
                  </div>
                  <XCircle className="h-8 w-8 text-destructive" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card className="shadow-card mb-6">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by name or document type..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending_review">Pending Review</SelectItem>
                    <SelectItem value="flagged">Flagged</SelectItem>
                    <SelectItem value="verified">Verified</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Export Report
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Documents List */}
          <div className="grid grid-cols-1 gap-6">
            {filteredDocuments.map((document) => (
              <Card key={document.id} className="shadow-card">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                    {/* Document Info */}
                    <div className="lg:col-span-2">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-foreground mb-1">
                            {document.user_name}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {getDocumentTypeDisplay(document.document_type)} • {new Date(document.created_at).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge variant={getStatusColor(document.verification_status) as any}>
                          {document.verification_status.replace('_', ' ')}
                        </Badge>
                      </div>

                      {document.extracted_data && (
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{document.extracted_data.full_name}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <FileText className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">
                              {document.extracted_data.aadhaar_number || 
                               document.extracted_data.pan_number || 
                               document.extracted_data.license_number}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Scores */}
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-muted-foreground">Confidence</span>
                          <span className="font-medium">{document.confidence_score}%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full" 
                            style={{ width: `${document.confidence_score}%` }}
                          ></div>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-muted-foreground">Fraud Score</span>
                          <span className={`font-medium ${getRiskLevel(document.fraud_score).color}`}>
                            {document.fraud_score}% ({getRiskLevel(document.fraud_score).label})
                          </span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div 
                            className="bg-success h-2 rounded-full" 
                            style={{ width: `${document.fraud_score}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col space-y-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedDoc(document)}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Review
                      </Button>
                      
                      {document.verification_status === 'pending_review' && (
                        <>
                          <Button
                            variant="default"
                            size="sm"
                            className="bg-success hover:bg-success/90"
                            onClick={() => {
                              setSelectedDoc(document);
                              setReviewAction('approve');
                            }}
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Approve
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              setSelectedDoc(document);
                              setReviewAction('reject');
                            }}
                          >
                            <XCircle className="h-4 w-4 mr-2" />
                            Reject
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Review Modal */}
          {selectedDoc && reviewAction && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <Card className="w-full max-w-lg shadow-elegant">
                <CardHeader>
                  <CardTitle>
                    {reviewAction === 'approve' ? 'Approve Document' : 'Reject Document'}
                  </CardTitle>
                  <CardDescription>
                    Review decision for {selectedDoc.user_name}'s {getDocumentTypeDisplay(selectedDoc.document_type)}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Confidence Score:</span>
                      <span className="font-medium ml-2">{selectedDoc.confidence_score}%</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Fraud Score:</span>
                      <span className={`font-medium ml-2 ${getRiskLevel(selectedDoc.fraud_score).color}`}>
                        {selectedDoc.fraud_score}%
                      </span>
                    </div>
                  </div>

                  <Textarea
                    placeholder="Add review comments (optional)"
                    value={reviewComments}
                    onChange={(e) => setReviewComments(e.target.value)}
                    className="min-h-[100px]"
                  />

                  <div className="flex space-x-3">
                    <Button
                      variant={reviewAction === 'approve' ? 'default' : 'destructive'}
                      onClick={handleReviewSubmit}
                      className="flex-1"
                    >
                      {reviewAction === 'approve' ? (
                        <CheckCircle className="h-4 w-4 mr-2" />
                      ) : (
                        <XCircle className="h-4 w-4 mr-2" />
                      )}
                      Confirm {reviewAction === 'approve' ? 'Approval' : 'Rejection'}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedDoc(null);
                        setReviewAction('');
                        setReviewComments('');
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;