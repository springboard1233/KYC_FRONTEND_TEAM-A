import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Eye, 
  FileText, 
  User, 
  Calendar, 
  MapPin, 
  Shield, 
  CheckCircle,
  AlertTriangle,
  ArrowLeft,
  Download,
  Loader2
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import FraudDetectionDashboard from "@/components/FraudDetectionDashboard";

interface Document {
  id: string;
  document_type: string;
  file_name: string;
  verification_status: string;
  extracted_data: any;
  verification_results: any;
  confidence_score: number;
  report_id: string;
  created_at: string;
}

const Preview = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [document, setDocument] = useState<Document | null>(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    if (id && user) {
      fetchDocument();
    }
  }, [id, user]);

  const fetchDocument = async () => {
    try {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('id', id)
        .eq('user_id', user?.id)
        .single();

      if (error) throw error;

      setDocument(data);

      // If document is pending, start AI verification
      if (data.verification_status === 'pending') {
        await processDocument(data);
      }
    } catch (error: any) {
      toast({
        title: "Error loading document",
        description: error.message,
        variant: "destructive",
      });
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const processDocument = async (doc: Document) => {
    setProcessing(true);
    
    // Enhanced AI processing simulation with stages
    const stages = [
      "Initializing AI models...",
      "Extracting text using OCR...", 
      "Validating document authenticity...",
      "Performing template matching...",
      "Analyzing security features...",
      "Running fraud detection algorithms...",
      "Cross-checking with databases...",
      "Calculating confidence scores..."
    ];

    for (let i = 0; i < stages.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      // You could show processing stage updates here
    }

    const mockExtractedData = {
      full_name: "Rahul Kumar Singh",
      aadhaar_number: "XXXX XXXX 1234",
      date_of_birth: "15/08/1990",
      father_name: "Suresh Kumar Singh",
      gender: "Male",
      address: "123 MG Road, Sector 15, Gurgaon, Haryana - 122001"
    };

    const mockVerificationResults = {
      document_authenticity: { score: 98.5, status: "passed" },
      template_matching: { score: 96.2, status: "passed" },
      security_features: { score: 99.1, status: "passed" },
      fraud_detection: { score: 97.3, status: "passed" },
      data_validation: { score: 95.8, status: "passed" }
    };

    const reportId = `VR-${Date.now().toString().slice(-8)}`;

    try {
      const { error } = await supabase
        .from('documents')
        .update({
          verification_status: 'verified',
          extracted_data: mockExtractedData,
          verification_results: mockVerificationResults,
          confidence_score: 97.8,
          report_id: reportId
        })
        .eq('id', doc.id);

      if (error) throw error;

      // Refresh document data
      await fetchDocument();
    } catch (error: any) {
      toast({
        title: "Verification failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen pt-20 pb-16 gradient-subtle flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading document...</p>
        </div>
      </div>
    );
  }

  if (!document) {
    return (
      <div className="min-h-screen pt-20 pb-16 gradient-subtle flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Document not found</h2>
          <Button onClick={() => navigate('/dashboard')}>Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified': return 'success';
      case 'failed': return 'destructive';
      case 'flagged': return 'warning';
      default: return 'secondary';
    }
  };

  const getDocumentTypeDisplay = (type: string) => {
    switch (type) {
      case 'aadhaar': return 'Aadhaar Card';
      case 'pan': return 'PAN Card';
      case 'driving_license': return 'Driving License';
      default: return type;
    }
  };

  return (
    <div className="min-h-screen pt-20 pb-16 gradient-subtle">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/dashboard')}
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
              <div>
                <div className="flex items-center space-x-2 mb-1">
                  <Eye className="h-6 w-6 text-primary" />
                  <h1 className="text-2xl font-bold">Document Preview</h1>
                </div>
                <p className="text-muted-foreground">
                  Review the extracted information and verification results
                </p>
              </div>
            </div>
            <Badge variant={getStatusColor(document.verification_status) as any} className="text-sm">
              {document.confidence_score ? `${document.confidence_score}%` : '0%'}
            </Badge>
          </div>

          {processing && (
            <Alert className="mb-6 border-primary/20 bg-primary/5">
              <Loader2 className="h-4 w-4 text-primary animate-spin" />
              <AlertDescription className="text-primary">
                <strong>AI Analysis in Progress:</strong> Running advanced fraud detection algorithms and document verification. This may take 30-60 seconds.
              </AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Document Information */}
            <div className="lg:col-span-2 space-y-6">
              {/* Document Details */}
              <Card>
                <CardHeader className="flex flex-row items-center space-y-0 pb-4">
                  <div className="flex items-center space-x-2">
                    <FileText className="h-5 w-5 text-primary" />
                    <CardTitle>{getDocumentTypeDisplay(document.document_type)}</CardTitle>
                  </div>
                  <Badge variant="outline" className="ml-auto">
                    {document.verification_status === 'verified' ? 'Verified' : 'Processing'}
                  </Badge>
                </CardHeader>
                <CardContent>
                  {document.extracted_data ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Full Name</p>
                            <p className="font-medium">{document.extracted_data.full_name}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Date of Birth</p>
                            <p className="font-medium">{document.extracted_data.date_of_birth}</p>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">
                              {document.document_type === 'aadhaar' ? 'Aadhaar Number' : 'Document Number'}
                            </p>
                            <p className="font-medium">{document.extracted_data.aadhaar_number}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Father's Name</p>
                            <p className="font-medium">{document.extracted_data.father_name}</p>
                          </div>
                        </div>
                      </div>
                      <div className="md:col-span-2">
                        <div className="flex items-start space-x-2">
                          <MapPin className="h-4 w-4 text-muted-foreground mt-1" />
                          <div>
                            <p className="text-sm text-muted-foreground">Address</p>
                            <p className="font-medium">{document.extracted_data.address}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <div className="animate-pulse">
                        <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto mb-2"></div>
                        <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
                      </div>
                      <p className="text-muted-foreground mt-4">Extracting document data...</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Fraud Detection Dashboard */}
              {document.verification_results && (
                <FraudDetectionDashboard document={document} />
              )}
            </div>

            {/* Verification Status & Actions */}
            <div className="space-y-6">
              {/* Status Card */}
              <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
                <CardContent className="p-6 text-center">
                  <div className="flex justify-center mb-4">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <CheckCircle className="h-8 w-8 text-primary" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-primary mb-2">
                    {document.verification_status === 'verified' ? 'Verification Successful' : 'Processing'}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {document.verification_status === 'verified' 
                      ? 'Document has passed all security checks with high confidence.'
                      : 'Document is being analyzed by our AI systems.'
                    }
                  </p>
                  {document.confidence_score && (
                    <div className="bg-primary/10 rounded-lg p-4">
                      <div className="text-2xl font-bold text-primary mb-1">
                        {document.confidence_score}%
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Overall Confidence
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Next Steps */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Next Steps</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {document.verification_status === 'verified' ? (
                    <>
                      <Button 
                        className="w-full" 
                        onClick={() => navigate(`/complete/${document.id}`)}
                      >
                        Confirm & Save
                        <Download className="ml-2 h-4 w-4" />
                      </Button>
                      <Button variant="outline" className="w-full">
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        Upload Another
                      </Button>
                    </>
                  ) : (
                    <div className="text-center py-4">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
                      <p className="text-sm text-muted-foreground">
                        Please wait while verification completes...
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Security Notice */}
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription className="text-sm">
                  <strong>Secure Processing:</strong> All verification is done using encrypted AI models. 
                  Your document is not stored on our servers.
                </AlertDescription>
              </Alert>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Preview;