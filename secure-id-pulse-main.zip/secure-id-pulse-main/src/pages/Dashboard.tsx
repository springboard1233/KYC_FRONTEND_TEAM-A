import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { 
  Upload, 
  FileCheck, 
  AlertTriangle, 
  Clock, 
  TrendingUp,
  Users,
  Shield,
  Activity,
  Download,
  Eye
} from "lucide-react";

const Dashboard = () => {
  const stats = [
    {
      title: "Total Verifications",
      value: "2,847",
      change: "+12%",
      trend: "up",
      icon: FileCheck,
      color: "text-success"
    },
    {
      title: "Pending Reviews",
      value: "23",
      change: "+5%", 
      trend: "up",
      icon: Clock,
      color: "text-warning"
    },
    {
      title: "Fraud Detected",
      value: "18",
      change: "-8%",
      trend: "down", 
      icon: AlertTriangle,
      color: "text-destructive"
    },
    {
      title: "Success Rate",
      value: "99.2%",
      change: "+0.3%",
      trend: "up",
      icon: TrendingUp,
      color: "text-success"
    }
  ];

  const recentVerifications = [
    {
      id: "VER-2024-001",
      name: "Rahul Sharma",
      document: "Aadhaar Card",
      status: "verified",
      confidence: 98.5,
      timestamp: "2 minutes ago"
    },
    {
      id: "VER-2024-002", 
      name: "Priya Patel",
      document: "PAN Card",
      status: "flagged",
      confidence: 65.2,
      timestamp: "15 minutes ago"
    },
    {
      id: "VER-2024-003",
      name: "Amit Kumar",
      document: "Driving License",
      status: "pending",
      confidence: 0,
      timestamp: "1 hour ago"
    },
    {
      id: "VER-2024-004",
      name: "Sneha Reddy",
      document: "Aadhaar Card", 
      status: "verified",
      confidence: 97.8,
      timestamp: "2 hours ago"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "verified":
        return <Badge variant="default" className="bg-success text-success-foreground">Verified</Badge>;
      case "flagged":
        return <Badge variant="destructive">Flagged</Badge>;
      case "pending":
        return <Badge variant="secondary">Pending</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen pt-20 pb-16 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor your KYC verification activities and manage compliance workflows
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Link to="/upload">
            <Card className="shadow-card hover:shadow-elegant transition-smooth cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="p-3 gradient-primary rounded-lg">
                    <Upload className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Upload Documents</h3>
                    <p className="text-sm text-muted-foreground">Verify Aadhaar, PAN, or DL</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link to="/compliance">
            <Card className="shadow-card hover:shadow-elegant transition-smooth cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="p-3 gradient-accent rounded-lg">
                    <Shield className="h-6 w-6 text-accent-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Compliance Center</h3>
                    <p className="text-sm text-muted-foreground">Review flagged cases</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Card className="shadow-card hover:shadow-elegant transition-smooth cursor-pointer">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-success/10 text-success rounded-lg">
                  <Activity className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Analytics</h3>
                  <p className="text-sm text-muted-foreground">View detailed reports</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">
                      {stat.title}
                    </p>
                    <p className="text-2xl font-bold text-foreground">
                      {stat.value}
                    </p>
                    <p className={`text-sm ${stat.color} flex items-center mt-1`}>
                      {stat.change} from last month
                    </p>
                  </div>
                  <div className={`p-3 ${stat.color.replace('text-', 'bg-')}/10 rounded-lg`}>
                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Verifications */}
          <div className="lg:col-span-2">
            <Card className="shadow-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Recent Verifications</CardTitle>
                    <CardDescription>
                      Latest document verification activities
                    </CardDescription>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link to="/verifications">View All</Link>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentVerifications.map((verification) => (
                    <div 
                      key={verification.id}
                      className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-smooth"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <FileCheck className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{verification.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {verification.document} • {verification.timestamp}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        {verification.confidence > 0 && (
                          <span className="text-sm text-muted-foreground">
                            {verification.confidence}%
                          </span>
                        )}
                        {getStatusBadge(verification.status)}
                        <div className="flex items-center space-x-1">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* System Status & Quick Stats */}
          <div className="space-y-6">
            {/* System Status */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>System Status</CardTitle>
                <CardDescription>Real-time platform health</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">API Status</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success rounded-full"></div>
                    <span className="text-sm text-success">Operational</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">OCR Engine</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success rounded-full"></div>
                    <span className="text-sm text-success">Online</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">AI Models</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success rounded-full"></div>
                    <span className="text-sm text-success">Active</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Response Time</span>
                  <span className="text-sm text-foreground">1.2s avg</span>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start" asChild>
                  <Link to="/bulk-upload">
                    <Upload className="h-4 w-4 mr-2" />
                    Bulk Upload
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-start" asChild>
                  <Link to="/reports">
                    <Download className="h-4 w-4 mr-2" />
                    Export Reports
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-start" asChild>
                  <Link to="/api-docs">
                    <Activity className="h-4 w-4 mr-2" />
                    API Documentation
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;