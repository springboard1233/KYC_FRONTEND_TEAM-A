import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { 
  Shield, 
  FileCheck, 
  Brain, 
  Zap, 
  Lock, 
  CheckCircle,
  ArrowRight,
  Star
} from "lucide-react";
import heroImage from "@/assets/hero-bg.jpg";
import aiScanIcon from "@/assets/ai-scan-icon.png";
import secureIcon from "@/assets/secure-icon.png";
import fraudDetectionIcon from "@/assets/fraud-detection-icon.png";

const LandingPage = () => {
  const features = [
    {
      icon: aiScanIcon,
      title: "AI-Powered Document Scanning",
      description: "Advanced OCR and NLP technology extracts and validates information from Aadhaar, PAN, and Driving License documents with 99.9% accuracy."
    },
    {
      icon: secureIcon,
      title: "Bank-Grade Security",
      description: "End-to-end encryption, secure data handling, and compliance with industry standards ensure your sensitive information stays protected."
    },
    {
      icon: fraudDetectionIcon,
      title: "Real-time Fraud Detection",
      description: "Sophisticated AI algorithms detect document tampering, fake IDs, and suspicious patterns to prevent fraudulent activities."
    }
  ];

  const benefits = [
    "Instant verification results",
    "99.9% accuracy rate",
    "GDPR & compliance ready",
    "24/7 API availability",
    "Real-time fraud alerts",
    "Audit trail & reporting"
  ];

  const stats = [
    { number: "10M+", label: "Documents Verified" },
    { number: "99.9%", label: "Accuracy Rate" },
    { number: "500+", label: "Enterprise Clients" },
    { number: "<2s", label: "Average Processing Time" }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="gradient-hero absolute inset-0 opacity-90" />
        
        <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold text-primary-foreground mb-6 leading-tight">
              AI-Powered KYC Verification
              <span className="block text-accent-light">Made Simple & Secure</span>
            </h1>
            <p className="text-xl md:text-2xl text-primary-foreground/90 mb-8 leading-relaxed">
              Verify Aadhaar, PAN, and Driving License documents instantly with our advanced AI platform. 
              Ensure compliance, prevent fraud, and streamline your verification process.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button variant="glass" size="lg" className="text-lg px-8 py-4" asChild>
                <Link to="/signup">
                  Start Free Trial
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 py-4 bg-white/10 border-white/20 text-primary-foreground hover:bg-white/20" asChild>
                <Link to="/demo">
                  Watch Demo
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-card">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">
                  {stat.number}
                </div>
                <div className="text-muted-foreground font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 gradient-subtle">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Powerful Features for Complete Verification
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Our AI-powered platform combines cutting-edge technology with robust security to deliver 
              the most reliable KYC verification solution in the market.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="shadow-card hover:shadow-elegant transition-smooth border-border/50">
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center">
                    <img src={feature.icon} alt={feature.title} className="w-12 h-12" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-4">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
                Why Choose VerifyAI?
              </h2>
              <p className="text-xl text-muted-foreground mb-8">
                Built for enterprises and compliance teams who demand the highest standards 
                of accuracy, security, and reliability in document verification.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-success flex-shrink-0" />
                    <span className="text-foreground font-medium">{benefit}</span>
                  </div>
                ))}
              </div>

              <div className="mt-8">
                <Button variant="hero" size="lg" className="text-lg px-8 py-4" asChild>
                  <Link to="/signup">
                    Get Started Today
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
            </div>

            <div className="relative">
              <Card className="shadow-elegant border-border/50">
                <CardContent className="p-8">
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="p-3 gradient-primary rounded-lg">
                      <Shield className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Enterprise Ready</h3>
                      <p className="text-sm text-muted-foreground">Trusted by 500+ companies</p>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Processing Speed</span>
                      <span className="text-sm font-medium text-success">Ultra Fast</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Security Level</span>
                      <span className="text-sm font-medium text-success">Military Grade</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Compliance</span>
                      <span className="text-sm font-medium text-success">GDPR Ready</span>
                    </div>
                    
                    <div className="pt-4 border-t border-border">
                      <div className="flex items-center space-x-2">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-warning text-warning" />
                        ))}
                        <span className="text-sm text-muted-foreground ml-2">4.9/5 rating</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-hero relative overflow-hidden">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-6">
            Ready to Transform Your KYC Process?
          </h2>
          <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
            Join thousands of businesses already using VerifyAI to streamline their verification workflows. 
            Start your free trial today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button variant="glass" size="lg" className="text-lg px-8 py-4" asChild>
              <Link to="/signup">
                Start Free Trial
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-4 bg-white/10 border-white/20 text-primary-foreground hover:bg-white/20" asChild>
              <Link to="/contact">
                Contact Sales
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;