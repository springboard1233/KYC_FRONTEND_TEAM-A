import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Upload as UploadIcon, FileText, Shield, Info } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

const Upload = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [documentType, setDocumentType] = useState<string>("");
  const [file, setFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      if (validateFile(droppedFile)) {
        setFile(droppedFile);
      }
    }
  }, []);

  const validateFile = (file: File) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
    const maxSize = 10 * 1024 * 1024; // 10MB

    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please upload JPEG, PNG, or PDF files only.",
        variant: "destructive",
      });
      return false;
    }

    if (file.size > maxSize) {
      toast({
        title: "File too large",
        description: "Please upload files smaller than 10MB.",
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      if (validateFile(selectedFile)) {
        setFile(selectedFile);
      }
    }
  };

  const handleUpload = async () => {
    if (!file || !documentType || !user) return;

    setUploading(true);

    try {
      // Upload file to Supabase Storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('documents')
        .upload(fileName, file);

      if (uploadError) {
        throw uploadError;
      }

      // Insert document record
      const { data: document, error: dbError } = await supabase
        .from('documents')
        .insert({
          user_id: user.id,
          document_type: documentType,
          file_name: file.name,
          file_path: fileName,
          verification_status: 'pending'
        })
        .select()
        .single();

      if (dbError) {
        throw dbError;
      }

      toast({
        title: "Upload successful",
        description: "Your document has been uploaded and is being processed.",
      });

      navigate(`/preview/${document.id}`);
    } catch (error: any) {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="min-h-screen pt-20 pb-16 gradient-subtle">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="p-4 gradient-primary rounded-2xl">
                <UploadIcon className="h-8 w-8 text-primary-foreground" />
              </div>
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Upload Document</h1>
            <p className="text-muted-foreground">
              Upload your Aadhaar, PAN, or Driving License for verification
            </p>
          </div>

          <Card className="shadow-elegant border-border/50">
            <CardHeader>
              <CardTitle className="text-2xl">Document Upload</CardTitle>
              <CardDescription>
                Select your document type and upload the file for AI-powered verification
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Document Type Selection */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Document Type</label>
                <Select value={documentType} onValueChange={setDocumentType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select document type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="aadhaar">Aadhaar Card</SelectItem>
                    <SelectItem value="pan">PAN Card</SelectItem>
                    <SelectItem value="driving_license">Driving License</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* File Upload Area */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Upload File</label>
                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-all ${
                    dragActive
                      ? "border-primary bg-primary/5"
                      : file
                      ? "border-success bg-success/5"
                      : "border-border hover:border-primary/50"
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <div className="flex flex-col items-center space-y-4">
                    <div className="p-3 rounded-full bg-primary/10">
                      <UploadIcon className="h-8 w-8 text-primary" />
                    </div>
                    
                    {file ? (
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2 text-success">
                          <FileText className="h-4 w-4" />
                          <span className="font-medium">{file.name}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          File ready for upload
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <h3 className="text-lg font-medium text-foreground">
                          Drag & drop your document here
                        </h3>
                        <p className="text-muted-foreground">
                          or{" "}
                          <label className="text-primary cursor-pointer hover:underline">
                            browse files
                            <input
                              type="file"
                              className="hidden"
                              accept=".pdf,.jpg,.jpeg,.png"
                              onChange={handleFileInput}
                            />
                          </label>
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Supports: JPEG, PNG, PDF (Max 10MB)
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Security Notice */}
              <Alert className="border-primary/20 bg-primary/5">
                <Info className="h-4 w-4 text-primary" />
                <AlertDescription className="text-primary">
                  <strong>Security Notice:</strong> Your documents are encrypted end-to-end and processed securely. 
                  We follow strict privacy policies and never store your documents permanently.
                </AlertDescription>
              </Alert>

              {/* Upload Button */}
              <Button
                onClick={handleUpload}
                disabled={!file || !documentType || uploading}
                className="w-full"
                variant="hero"
                size="lg"
              >
                <UploadIcon className="mr-2 h-4 w-4" />
                {uploading ? "Processing..." : "Upload & Verify"}
              </Button>
            </CardContent>
          </Card>

          {/* Security Features */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              {
                icon: Shield,
                title: "End-to-End Encryption",
                description: "Your documents are encrypted during transfer and processing"
              },
              {
                icon: FileText,
                title: "AI-Powered Verification",
                description: "Advanced AI models ensure accurate document validation"
              },
              {
                icon: Info,
                title: "Compliance Ready",
                description: "Meets KYC/AML requirements and regulatory standards"
              }
            ].map((feature, index) => (
              <Card key={index} className="text-center p-4">
                <div className="flex justify-center mb-2">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-medium text-sm mb-1">{feature.title}</h3>
                <p className="text-xs text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Upload;