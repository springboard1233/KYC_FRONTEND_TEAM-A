import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  CheckCircle, 
  Download, 
  FileText, 
  ArrowLeft, 
  Eye, 
  Share,
  Clock,
  Calendar,
  User,
  Shield,
  AlertCircle
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface Document {
  id: string;
  document_type: string;
  file_name: string;
  verification_status: string;
  extracted_data: any;
  verification_results: any;
  confidence_score: number;
  report_id: string;
  created_at: string;
}

const Complete = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [document, setDocument] = useState<Document | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id && user) {
      fetchDocument();
    }
  }, [id, user]);

  const fetchDocument = async () => {
    try {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('id', id)
        .eq('user_id', user?.id)
        .single();

      if (error) throw error;
      setDocument(data);
    } catch (error: any) {
      toast({
        title: "Error loading document",
        description: error.message,
        variant: "destructive",
      });
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const downloadReport = (format: 'pdf' | 'json') => {
    toast({
      title: "Download started",
      description: `Downloading verification report in ${format.toUpperCase()} format.`,
    });
  };

  const shareReport = () => {
    navigator.clipboard.writeText(document?.report_id || '');
    toast({
      title: "Report ID copied",
      description: "Share this ID with authorized third parties.",
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen pt-20 pb-16 gradient-subtle flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading verification report...</p>
        </div>
      </div>
    );
  }

  if (!document) {
    return (
      <div className="min-h-screen pt-20 pb-16 gradient-subtle flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Document not found</h2>
          <Button onClick={() => navigate('/dashboard')}>Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  const getDocumentTypeDisplay = (type: string) => {
    switch (type) {
      case 'aadhaar': return 'Aadhaar Card';
      case 'pan': return 'PAN Card';
      case 'driving_license': return 'Driving License';
      default: return type;
    }
  };

  const verificationDate = new Date(document.created_at);
  const validUntil = new Date(verificationDate.getTime() + 365 * 24 * 60 * 60 * 1000); // 1 year

  return (
    <div className="min-h-screen pt-20 pb-16 gradient-subtle">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="p-4 bg-success/10 rounded-full">
                <CheckCircle className="h-8 w-8 text-success" />
              </div>
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Verification Complete</h1>
            <p className="text-muted-foreground">
              Your document has been successfully verified and is ready for download
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Verification Report */}
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-xl">Verification Report</CardTitle>
                      <CardDescription>Report ID: {document.report_id}</CardDescription>
                    </div>
                    <Badge variant="outline" className="text-success border-success">
                      Verified
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground">Document Type</p>
                        <p className="font-medium">{getDocumentTypeDisplay(document.document_type)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Document Holder</p>
                        <p className="font-medium">{document.extracted_data?.full_name}</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm text-muted-foreground">Verification Date</p>
                          <p className="font-medium">{verificationDate.toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm text-muted-foreground">Verification Time</p>
                          <p className="font-medium">{verificationDate.toLocaleTimeString()}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Overall Confidence</h3>
                      <div className="text-2xl font-bold text-success">
                        {document.confidence_score}%
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Valid Until: {validUntil.toLocaleDateString()}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Verification Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Verification Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="p-4 bg-success/10 rounded-lg">
                      <div className="text-2xl font-bold text-success mb-1">5</div>
                      <div className="text-sm text-muted-foreground">Passed</div>
                    </div>
                    <div className="p-4 bg-gray-100 rounded-lg">
                      <div className="text-2xl font-bold text-muted-foreground mb-1">0</div>
                      <div className="text-sm text-muted-foreground">Failed</div>
                    </div>
                    <div className="p-4 bg-gray-100 rounded-lg">
                      <div className="text-2xl font-bold text-muted-foreground mb-1">0</div>
                      <div className="text-sm text-muted-foreground">Warnings</div>
                    </div>
                  </div>

                  <div className="mt-6 space-y-3">
                    <h4 className="font-medium">Checks Performed</h4>
                    {document.verification_results && Object.entries(document.verification_results).map(([key, result]: [string, any]) => (
                      <div key={key} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-success" />
                          <span className="capitalize">{key.replace(/_/g, ' ')}</span>
                        </div>
                        <Badge variant="outline" className="text-success border-success">
                          Passed
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Download & Actions */}
            <div className="space-y-6">
              {/* Download Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Download Report</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    className="w-full" 
                    onClick={() => downloadReport('pdf')}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download PDF
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => downloadReport('json')}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download JSON
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={shareReport}
                  >
                    <Share className="mr-2 h-4 w-4" />
                    Share Report ID
                  </Button>
                </CardContent>
              </Card>

              {/* Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => navigate('/dashboard')}
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back to Dashboard
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => navigate('/upload')}
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    Verify Another Document
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => navigate(`/preview/${document.id}`)}
                  >
                    <Eye className="mr-2 h-4 w-4" />
                    View Original Document
                  </Button>
                </CardContent>
              </Card>

              {/* Report Information */}
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-sm">
                  <div className="space-y-2">
                    <p><strong>Report Information:</strong></p>
                    <ul className="text-xs space-y-1">
                      <li>• Reports are valid for 1 year from verification date</li>
                      <li>• Can be shared with authorized third parties</li>
                      <li>• Compliant with data protection regulations</li>
                      <li>• Digital signature ensures authenticity</li>
                    </ul>
                  </div>
                </AlertDescription>
              </Alert>

              {/* Help Section */}
              <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
                <CardContent className="p-4 text-center">
                  <h3 className="font-medium text-primary mb-2">Need Help?</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Contact our support team if you have questions about your verification report.
                  </p>
                  <Button variant="outline" size="sm" className="w-full">
                    <Shield className="mr-2 h-4 w-4" />
                    Get Support
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Complete;